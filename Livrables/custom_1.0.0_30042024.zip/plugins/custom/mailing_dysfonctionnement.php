<?php
require __DIR__ . '/vendor/autoload.php';
require_once 'sendMail.php';
// Inclusion du fichier de configuration contenant les informations de connexion à la base de données
require_once 'config.php';

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https://" : "http://";

// Récupérez le nom de domaine
$domain = $_SERVER['HTTP_HOST'];

$url_root = $protocol . $domain . $CFG_GLPI['root_doc'];

function getContent($message)
{
  global $url_root;
  $urlLogo = $url_root. '/plugins/custom/img/logo.png';

  $htmlContent = "
    <!DOCTYPE html>
    <html lang='fr'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>GLPI</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f9f9f9;
            }
            .container {
                max-width: 600px;
                margin: 20px auto;
                padding: 20px;
                background-color: #ffffff;
                border-radius: 10px;
                box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            }
            p {
                font-size: 16px;
                line-height: 1.6;
                color: #333333;
                margin-bottom: 10px;
            }
            .footer {
                font-size: 14px;
                color: #666666;
                text-align: right;
                margin-top: 20px;
            }
            .logo {
                text-align: center;
                margin-bottom: 20px;
            }
            .logo img {
                max-width: 100px;
                height: auto;
            }
        </style>
    </head>
    <body>

        <div class='container'>
            <div class='logo'>
                <img src='data:image/png;base64," . base64_encode(file_get_contents($urlLogo)) . "' alt='Logo'>
            </div>
            <p>Bonjour,</p>
            ". $message . "
            <p>N'hésitez pas à nous contacter si vous avez des questions.</p>
            <p>Cordialement,</p>
        </div>

    </body>
    </html>
    ";
  return $htmlContent;
}

function send_mailing_creation_dysfonctionnement()
{
  global $url_root;
  $url_answer = $url_root . "/plugins/formcreator/front/formanswer.php";
  
  $mails_demandeur = [$_POST['formcreator_field_'.getIdField('contact', 'Courriel')], getUserEmail($_SESSION['glpiID'])];
  $content = getContent("<p>Votre nouveau signalement de dysfonctionnement a bien été ajouté ce " . date('d/m/Y') . ". Vous trouverez la liste des signalements de dysfonctionnement sur ce <a href='$url_answer'>$url_answer</a></p>");
  SendMail($content, $mails_demandeur, "Nouveau signalement de dysfonctionnement");

  //$mails_valideur = getMailsOfGroup('Direction/Service (validation)');
  $mails_valideur = getMailsValideur($_SESSION['glpiID']);
  $content = getContent("<p>Nous vous signalons qu'un nouveau signalement a été ajouté ce " . date('d/m/Y') . ". Vous trouverez la liste des signalements de dysfonctionnement sur ce <a href='$url_answer'>$url_answer</a></p>");
  SendMail($content, $mails_valideur, "Nouveau signalement de dysfonctionnement");
}

function send_mailing_validation_dysfonctionnement()
{
  global $url_root;
  $url_answer = $url_root . "/plugins/formcreator/front/formdisplay.php?id=1&answer=".$_SESSION['id_answer'];

  $mails_demandeur = [$_POST['formcreator_field_'.getIdField('contact', 'Courriel')], getUserEmail(getIdDemandeurOfSignalement($_SESSION['id_answer']))];
  $content = getContent("<p>Votre signalement de dysfonctionnement a bien été validé ce " . date('d/m/Y') . ". Vous trouverez ce signalement de dysfonctionnement sur ce <a href='$url_answer'>$url_answer</a></p>");
  SendMail($content, $mails_demandeur, "Validation d'un signalement de dysfonctionnement");

  $mail_valideur = getUserEmail($_SESSION['glpiID']);
  $content = getContent("<p>Vous avez validé un signalement de dysfonctionnement ce " . date('d/m/Y') . ". Vous trouverez ce signalement de dysfonctionnement sur ce <a href='$url_answer'>$url_answer</a></p>");
  SendMail($content, $mail_valideur, "Validation d'un signalement de dysfonctionnement");
}

function send_mailing_cloture_dysfonctionnement()
{
  global $url_root;
  $url_answer = $url_root . "/plugins/formcreator/front/formdisplay.php?id=1&answer=".$_SESSION['id_answer'];

  $mails_demandeur = [$_POST['formcreator_field_'.getIdField('contact', 'Courriel')], getUserEmail(getIdDemandeurOfSignalement($_SESSION['id_answer']))];
  $content = getContent("<p>Votre signalement de dysfonctionnement a bien été clôturé ce " . date('d/m/Y') . ". Vous trouverez ce signalement de dysfonctionnement sur ce <a href='$url_answer'>$url_answer</a></p>");
  SendMail($content, $mails_demandeur, "Validation d'un signalement de dysfonctionnement");

  // $mails_valideur = getMailsOfGroup('Direction/Service (validation)');
  $mails_valideur = getMailsValideur($_SESSION['glpiID']);
  $content = getContent("<p>Nous vous signalons qu'un signalement a été clôturé ce " . date('d/m/Y') . ". Vous trouverez ce signalement de dysfonctionnement sur ce <a href='$url_answer'>$url_answer</a></p>");
  SendMail($content, $mails_valideur, "Validation d'un signalement de dysfonctionnement");
}

function send_mailing_import_dysfonctionnement()
{
  global $url_root;
  $url_answer = $url_root . "/plugins/formcreator/front/formanswer.php";

  // $mails_valideur = getMailsOfGroup('Direction/Service (validation)');
  $mails_valideur = getMailsValideur($_SESSION['glpiID']);
  $content = getContent("<p>Nous vous signalons que des nouveaux signalements ont été ajoutés ce " . date('d/m/Y') . ". Vous trouverez la liste des signalements de dysfonctionnement sur ce lien <a href='$url_answer'>$url_answer</a></p>");
  SendMail($content, $mails_valideur, "Nouveau signalement de dysfonctionnement");
}

