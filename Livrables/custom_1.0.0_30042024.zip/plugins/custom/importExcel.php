<meta charset="utf-8" />
<pre>
<?php
require 'vendor/autoload.php';
include 'functions-dea93.php';
include ('mailing_dysfonctionnement.php');
include ('../../inc/includes.php');
use PhpOffice\PhpSpreadsheet\IOFactory;
    // Inclusion du fichier de configuration
    include('config.php');
    // Décommenter pour voir le contenu de $_POST
    // print_r($_POST);

    // Variable permettant de décider si les tables doivent être vidées (en provenance d'un formulaire POST)
    $truncate_tables =  $_POST['truncate_table'];
    // Fonction pour convertir une date du format français au format ANSI
    function dateFr2Ansi($date) { return implode('-', array_reverse(explode('/', $date))); }
    function _get_values($data, $key, $values) {
        $values = explode(',', trim($values, '[]'));
        $i = 0;
        $val = [];
        foreach($data as $k => $v) {
            if (str_starts_with($k, $key)) {
                
                if ($data[$k]) $val[] = $values[$i];
                $i++;
            }
        }
        return $val;
    }
    function cb_values($data) {
        $result='';
        switch ($data) {
            case 'R+1':
                $result = '1er';
                break;
            case 'R+2':
                $result = '2ème';
                break;
            case 'R-1':
                $result = 'Sous sol -1';
                break;
            case 'R-2':
                $result = 'Sous sol -2';
                break;
            case 'R-3':
                $result = 'Sous sol -3';
                break;
            case 'RDC':
                $result = 'RdC';
                break;
            default:
                $result= $data;
        }
        return '["'.$result.'"]';
    }
    function radio_value($data, $key, $values) {
        return @trim(_get_values($data, $key, $values)[0], '"');
    }

    try {
        $pdo = new PDO($db_host, $db_user, $db_pass);
        // $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);

        // Vidage des tables si $truncate_tables est vrai
        if ($truncate_tables) {
            $pdo->query("TRUNCATE TABLE glpi_plugin_formcreator_formanswers");
            $pdo->query("TRUNCATE TABLE glpi_plugin_formcreator_answers");
        }
        
        // Charger le fichier Excel
        $reader = IOFactory::createReader('Xls');

        $spreadsheet = $reader->load($_FILES['import_file_1']['tmp_name']);
        $worksheet = $spreadsheet->getActiveSheet();

        // Boucle de lecture des lignes du fichier Excel
        foreach ($worksheet->getRowIterator() as $row) {
            // Traitement différent pour la première ligne (titres)
            if ($row->getRowIndex() == 3) {
                $titres = [];
                foreach ($row->getCellIterator() as $cell) {
                    $titres[] = is_string($cell->getValue()) ? trim($cell->getValue()) : $cell->getValue() ;
                }
                // ...
            } else if($row->getRowIndex() > 3) {
                $data = [];
                foreach ($row->getCellIterator() as $cell) {
                    $data[] = $cell->getValue();
                }
                $dataWithTitle = array_combine($titres, $data);
                $date = date('Y-m-d H:i:s');
                $sql = "INSERT INTO `glpi_plugin_formcreator_formanswers` (`name`, `entities_id`, `is_recursive`, `plugin_formcreator_forms_id`, `requester_id`, `users_id_validator`, `groups_id_validator`, `request_date`, `status`, `comment`) VALUES
                            ('Signalement de dysfonctionnement', 0, 0, 1, 2, 0, 0, '$date', 103, '')";
                $pdo->query($sql);
                $lastInsertId = $pdo->lastInsertId();
                
                $sql = 'SELECT s.id s_id, s.name s_name, q.id q_id, q.name q_name, q.values q_values, fieldtype
                        FROM glpi_plugin_formcreator_questions q
                        JOIN glpi_plugin_formcreator_sections s ON s.id = q.plugin_formcreator_sections_id
                        WHERE s.plugin_formcreator_forms_id = 1
                        ORDER BY s.order, q.row';
                $res1 = $pdo->query($sql);

                foreach($res1 as $row1) {
                    $value = "";
                    switch(("$row1[s_name]:$row1[q_name]")) {
                        case "Signalement de dysfonctionnement:Date du signalement":                       $value = ""; break;
                        case "Déposé par:Nom":                                                             $value = ""; break;
                        case "Déposé par:Prénom":                                                          $value = ""; break;
                        case "Déposé par:Fonction":                                                        $value = $dataWithTitle['Utilisateur']; break;
                        case "Sous couvert de:Nom":                                                        $value = "" ; break;
                        case "Sous couvert de:Prénom":                                                     $value = "" ; break;
                        case "Sous couvert de:Fonction":                                                   $value = "" ; break;
                        case "Personne à contacter:Nom":                                                   $value = "" ; break;
                        case "Personne à contacter:Prénom":                                                $value = "" ; break;
                        case "Personne à contacter:Fonction":                                              $value = "" ; break;
                        case "Personne à contacter:Courriel":                                              $value = "" ; break;
                        case "Personne à contacter:Téléphone(s)":                                          $value = "" ; break;
                        case "Localisation du dysfonctionnement:Bâtiment":                                 $value = cb_values($dataWithTitle["Bâtiment"]); break;
                        case "Localisation du dysfonctionnement:Niveau":                                   $value = cb_values($dataWithTitle["Etage"]); break;
                        case "Localisation du dysfonctionnement:Description précise du dysfonctionnement": $value = $dataWithTitle['Travaux à effectuer']."\n".$dataWithTitle["Statut des travaux"]; break;
                        case "Localisation du dysfonctionnement:Niveau d impact sur l activité":           $value = "" ; break;
                        case "Localisation du dysfonctionnement:Qualification du dysfonctionnement":       $value = "" ; break;
                        case "Localisation du dysfonctionnement:Date du constat de dysfonctionnement":     $value = "" ; break;
                        case "Localisation du dysfonctionnement:Visa du demandeur":                        $value = '["Viser"]'; break;
                        case "Localisation du dysfonctionnement:Visa Direction ou Service":                $value = "" ; break;
                        case "Partie réservée au BMO:N° demande":                                          $value = "" ; break;
                        case "Partie réservée au BMO:Signalement reçu le":                                 $value = "" ; break;
                        case "Partie réservée au BMO:Caractérisation de la demande":                       $value = "" ; break;
                        case "Partie réservée au BMO:Prise en charge apportée":                            $value = "" ; break;
                        case "Partie réservée au BMO:Référent de la prise en charge":                      $value = "" ; break;
                        case "Partie réservée au BMO:Observations":                                        $value = $dataWithTitle["Changement d'utilisateur"]."\n".$dataWithTitle["Emplacement"]."\n".$dataWithTitle["Numérotation DCE"]."\n".$dataWithTitle["Local"]."\n".$dataWithTitle["Changements d'occupants de local"] ; break;
                        case "Partie réservée au BMO:Signalement clôturé le":                              $value = "" ; break;
                    }
                    $value = $pdo->quote($value);

                    $sql = "INSERT INTO `glpi_plugin_formcreator_answers` (`plugin_formcreator_formanswers_id`, `plugin_formcreator_questions_id`, `answer`) VALUES
                            ($lastInsertId, $row1[q_id], $value)";
                    $pdo->query($sql);
                }
            }
        }
        send_mailing_import_dysfonctionnement();
    } catch (\Exception $e) {
        print_r($e);
    }      
        
       