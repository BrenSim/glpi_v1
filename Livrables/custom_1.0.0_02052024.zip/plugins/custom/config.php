<?php
$db_host = "mysql:host=localhost;dbname=glpidb;charset=utf8";
$db_user = "glpi";
$db_pass = "password";

if (!class_exists('MailConfig'))
{
  class MailConfig
  {
    public static $host = 'mail.aquaray.com';
    public static $username = 'dea-niagara@eniagara.fr';
    public static $password = 'sWnSg6c6Md344uc';
    public static $SMTPAuth = true;
    public static $SMTPAutoTLS = false;
    public static $port = 587;
    public static $charset = 'UTF-8';
    public static $from = ['address' => 'noreply@eniagara.fr', 'name' => 'Equipe DEA'];
    public static $replyto = ['address' => 'noreply@eniagara.fr', 'name' => 'noreply@eniagara.fr'];
  };
}
