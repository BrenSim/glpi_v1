# Introduction
    **GLPI (sigle de Gestionnaire Libre de Parc Informatique) est un logiciel libre de gestion des services informatiques (ITSM) et de gestion des services d'assistance (issue tracking system et ServiceDesk). Cette solution libre est éditée en PHP et distribuée sous licence GPL.**

## Fonctionnalités supplémentaire
    ** Télecharger le plugin GLPI sur [Lien](https://github.com/pluginsGLPI/formcreator/releases). **
    ** Après que vous êtes sur Github **
    ![Capture](img/Capture%20d’écran%202023-12-19%20144152.png)
    ** Cliquer sur ce qui est entourée en rouge **
        - Un fichier .tar.bz2 sera télécharger dans votre navigateur préférer
        - Unzip ce fichier 
        - Vous obtiendrez un dossier  ![Capture](img/Capture%20d’écran%202023-12-19%20145405.png)
        - Prenez ce dossier mettez-le dans votre projet GLPI 

                Si vous utilisé WampServer :
                    - Aller  dans le dossier wamp64
                    - Puis dans www
                    - Ensuite dans glpi : 
                            - Entrer dans plugins, copier le dossier formcreator dedans
    
        - Après avoir enchainé toutes les étapes : 
            - Veuillez suivre les étapes suivantes :
                - Entrer dans l'application GLPI à l'aide d'un utilisateur bien dédié
                - Cliquer sur configuration :
                        - Cliquer sur Plugins
                            - Cliquer sur le checkbox 
                            ![Capture](img/Capture%20d’écran%202023-12-19%20154135.png)
                            - Maintenant que le plugin est activé, un nouveau sous-menu sera insérer automatique dans Administration
                                -> Cliquer sur Formulaires qui le sous-menu générer automatique par Formcreator
                            - Veuilliez suivre maitenant les étapes quivants : 
                                ![Capture](img/Capture%20d’écran%202023-12-19%20161134.png) => Cliquer sur ajouter
                            - Completer les champs comme suit :
                            ![Capture](img/Capture%20d’écran%202023-12-19%20163200.png) => Cliquer sur ajouter
                            ![Capture](img/Capture%20d’écran%202023-12-19%20165143.png) => Cliquer sur Signalement de dysfonctionnement
                            ![Capture](img/Capture%20d’écran%202023-12-19%20171041.png) => Cliquer sur Questions
                            - Cliquer sur ajouter une section ![Capture](img/Capture%20d’écran%202023-12-20%20085849.png)
                                - ![Capture](img/Capture%20d’écran%202023-12-20%20090020.png)
                                - Après ajout du section on aura ça par exemple ![Capture](img/Capture%20d’écran%202023-12-20%20090020.png)
                                - Cliquer sur ajouter une question dans la section 
                                - ![Capture](img/Capture%20d’écran%202023-12-20%20090546.png)
                - Maintenant que tu as créé toutes les sections et questions que tu auras besoin dans ton formulaire
                    - Aller sur Réponses au formulaire
                        - ![Capture](img/Capture%20d’écran%202023-12-20%20093240.png)
                        - Cliquer sur choisir un fichier pour importer du fichier
                        - Après import tu peux exporter
