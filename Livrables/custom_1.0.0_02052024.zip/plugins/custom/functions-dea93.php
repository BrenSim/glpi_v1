<?php
// Fonctions pour GLPI DEA 93
// ARR 08/04/2024

// Find ID sections ...
function getIdSection($name)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM' => 'glpi_plugin_formcreator_sections',
      'WHERE' => ['name' => ['LIKE', "%$name%"]]
  ]);
  return $iterator->current()['id'] ?? null;
}

function getIdSectionBMO() { return getIdSection('BMO'); }
function getIdSectionValideur() { return getIdSection('validation'); }

function getIdGroupByName($name)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM' => 'glpi_groups',
      'WHERE' => ['name' => ['LIKE', "%$name%"]]
  ]);
  return $iterator->current()['id'] ?? 6603;
}

// ARR 16/04/2024
function getIdNomValideur()
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM' => 'glpi_plugin_formcreator_questions',
      'WHERE' => ['plugin_formcreator_sections_id' => getIdSectionValideur(), 'fieldtype' => 'text']
  ]);
  return $iterator->current()['id'] ?? null;
}

function getIdVisaValideur()
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM' => 'glpi_plugin_formcreator_questions',
      'WHERE' => ['plugin_formcreator_sections_id' => getIdSectionValideur(), 'fieldtype' => 'radios']
  ]);
  return $iterator->current()['id'] ?? null;
}

function getIdFields($id_section)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM' => 'glpi_plugin_formcreator_questions',
      'WHERE' => ['plugin_formcreator_sections_id' => $id_section]
  ]);
  $ret = []; foreach($iterator as $row) $ret[] = $row['id'];
  return $ret;
}

function getIdField($section, $name)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM' => 'glpi_plugin_formcreator_questions',
      'WHERE' => ['plugin_formcreator_sections_id' => getIdSection($section), 'name' => ['LIKE', "%$name%"]]
  ]);
  $ret = []; foreach($iterator as $row) $ret[] = $row['id'];
  return $ret[0] ?? 0;
}

function getAnswerValidation($id_answer)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['answer'],
      'FROM' => 'glpi_plugin_formcreator_answers',
      'WHERE' => ['plugin_formcreator_formanswers_id' => $id_answer, 'plugin_formcreator_questions_id' => getIdVisaValideur()]
  ]);
  return $iterator->current()['answer'] ?? '';
}

function isAnswerValidated($id_answer) { return getAnswerValidation($id_answer) == "Valider"; }
function isAnswerRefused($id_answer) { return getAnswerValidation($id_answer) == "Refuser"; }

// ARR 17/04/2024
function isBMOFilled($id_answer)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['answer'],
      'FROM' => 'glpi_plugin_formcreator_answers',
      'WHERE' => ['plugin_formcreator_formanswers_id' => $id_answer, 'plugin_formcreator_questions_id' => getIdField('BMO', 'Observations')]
  ]);
  $val = $iterator->current()['answer'] ?? '';
  return !empty($val);
}

function validateAnswers()
{
  include('config.php');
  $user_name = $_SESSION['glpifirstname']." ".$_SESSION['glpirealname'];
  $pdo = new PDO($db_host, $db_user, $db_pass);
  $sql = "UPDATE glpi_plugin_formcreator_answers SET answer = ? WHERE plugin_formcreator_formanswers_id = ? AND plugin_formcreator_questions_id = ?";
  $stmt = $pdo->prepare($sql);
  $stmt->execute([$user_name, $_SESSION['id_answer'], getIdNomValideur()]);
  $stmt->execute([date('Y-m-d H:i'), $_SESSION['id_answer'], getIdField('validation', 'Date')]);
  $stmt->execute([$_POST['formcreator_field_'.getIdVisaValideur()], $_SESSION['id_answer'], getIdVisaValideur()]);
  $stmt = null;
  $pdo = null;
}

function saveBMOData()
{
  global $DB;
  include('config.php');

  $idDateClotureSignalament = getIdField('BMO', 'clôturé');
  $idDateReceptionSignalament = getIdField('BMO', 'reçu');
  $dateClotureSignalement = $_POST['formcreator_field_' . $idDateClotureSignalament] ?? '';
  $dateReceptionSignalement = $_POST['formcreator_field_' . $idDateReceptionSignalament] ?? '';
  if(!empty($dateReceptionSignalement) && !empty($dateClotureSignalement)){
    if ($dateReceptionSignalement > $dateClotureSignalement)
      return false;
  }
  $user_name = $_SESSION['glpifirstname']." ".$_SESSION['glpirealname'];
  $pdo = new PDO($db_host, $db_user, $db_pass);
  foreach(getIdFields(getIdSectionBMO()) as $id_field)
  {
    if (!isset($_POST['formcreator_field_'.$id_field]) || empty($_POST['formcreator_field_'.$id_field])) return false;
    $answer = html_entity_decode($DB->escape($_POST['formcreator_field_'.$id_field]));
    $id_form = $_SESSION['id_answer'];
    $id_quest = $id_field;
    $pdo->query("UPDATE glpi_plugin_formcreator_answers SET answer = '$answer' WHERE plugin_formcreator_formanswers_id = $id_form AND plugin_formcreator_questions_id = $id_quest");
  }
  $stmt = null;
  $pdo = null;
  return true;
}

function getEmailByUser($id_user)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['email'],
      'FROM' => 'glpi_useremails',
      'WHERE' => ['users_id' => $id_user]
  ]);
  return $iterator->current();
}

function getTitle($id_title)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id', 'name'],
      'FROM' => 'glpi_usertitles',
      'WHERE' => ['id' => $id_title]
  ]);
  return $iterator->current();
}

function getUser($id_user)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id', 'name', 'firstname', 'realname', 'usertitles_id', 'entities_id', 'users_id_supervisor', 'phone'],
      'FROM' => 'glpi_users',
      'WHERE' => ['id' => $id_user]
  ]);
  $user = $iterator->current(); 
  $user['title'] = getTitle($user['usertitles_id'])['name'] ?? '';
  $user['email'] = getEmailByUser($user['id'])['email'] ?? '';
  return $user;
}

function getUsersByGroupId2($id_group)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['users_id'],
      'FROM' => 'glpi_groups_users',
      'WHERE' => ['groups_id' => $id_group]
  ]);
  $ids = []; foreach($iterator as $row) $ids[] = $row;
  return $users;
}

function getUsersByGroupId($id_group)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['users_id AS id'],
      'FROM' => 'glpi_groups_users',
      'WHERE' => ['groups_id' => $id_group]
  ]);
  $users = [];
  foreach($iterator as $row)
  {
    $iterator1 = $DB->request([
        'SELECT' => ['id', 'name', 'entities_id AS id_entity'],
        'FROM' => 'glpi_users',
        'WHERE' => ['id' => $row['id']]
    ]);
    $user = $iterator1->current();
    $user['email'] = getEmailByUser($row['id'])['email'] ?? '';
    $users[] = $user;
  }
  return $users;
}

function getUserGroups()
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['groups.name as group_name'],
      'FROM' => 'glpi_groups_users AS groups_users',
      'JOIN' => [
        'glpi_groups AS groups' => [
           'ON' => [
             'groups' => 'id',
             'groups_users' => 'groups_id',
           ]
        ]
      ],
      'WHERE' => ['users_id' => $_SESSION['glpiID']]
  ]);
  $groups = []; foreach ($iterator as $row) {
    if ($row['group_name'] == 'Demandeur') $groups[] = 'demandeur';
    if ($row['group_name'] == 'Direction/Service (validation)') $groups[] = 'valideur';
  }
  return $groups;
}

function getUserProfile()
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['profiles.name as profiles'],
      'FROM' => 'glpi_profiles_users AS profiles_users',
      'JOIN' => [
        'glpi_profiles AS profiles' => [
           'ON' => [
             'profiles' => 'id',
             'profiles_users' => 'profiles_id',
           ]
        ]
      ],
      'WHERE' => ['users_id' => $_SESSION['glpiID']]
  ]);
  $profil = ''; 
  if(count($iterator)>0){
    foreach ($iterator as $row) {
      $profil = $row["profiles"];
    };
  }
  return $profil;
}

function isDemandeur()
{
  return in_array('demandeur', getUserGroups());
}

function isValideur()
{
  return in_array('valideur', getUserGroups());
}

// Récupération des questions d'un formulaire
function getQuestions($idForm = 1)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['plugin_formcreator_forms_id AS id_form', 'section.id AS id_section', 'question.id AS id_question', 'fieldtype'],
      'FROM' => 'glpi_plugin_formcreator_sections AS section',
      'JOIN' => [
        'glpi_plugin_formcreator_questions AS question' => [
           'ON' => [
              'question' => 'plugin_formcreator_sections_id',
              'section' => 'id',
           ]
        ]
      ],
      'WHERE' => [
        'plugin_formcreator_forms_id' => $idForm,
      ]
  ]);
  $questions = []; foreach ($iterator as $row) $questions[$row['id_question']] = $row;
  return $questions;
}

// Récupération des données du demandeur
function getAnswers($idAnswer = 0)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['plugin_formcreator_formanswers_id AS id_answer', 'plugin_formcreator_questions_id AS id_question', 'plugin_formcreator_sections_id AS id_section', 'answer', 'fieldtype'],
      'FROM' => 'glpi_plugin_formcreator_answers AS answer',
      'JOIN' => [
        'glpi_plugin_formcreator_questions AS question' => [
           'ON' => [
              'answer' => 'plugin_formcreator_questions_id',
              'question' => 'id',
           ]
        ]
      ],
      'WHERE' => [
        'plugin_formcreator_formanswers_id' => $idAnswer,
        // 'plugin_formcreator_sections_id' => ['<>', getIdSectionBMO()],
      ]
  ]);
  $answers = []; foreach ($iterator as $row) $answers[$row['id_question']] = $row;
  return $answers;
}

// Récupération identifiant question à partir de son nom
function getIdQuestionByName($questionName = '')
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM' => 'glpi_plugin_formcreator_questions',
      'WHERE' => [
        'name' => $questionName,
      ],
      'ORDERBY' => [
        'plugin_formcreator_sections_id'
    ]
  ]);
  $answers = []; foreach ($iterator as $row) $answers[] = $row;
  return count($answers)>0 ? $answers : [['id'=>'0']] ;
}

function getUserEmail($id)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['email'],
      'FROM' => 'glpi_useremails',
      'WHERE' => ['users_id' => $id]
  ]);
  return $iterator->current()['email'] ?? '';
}

function getIdDemandeurOfSignalement($id_answer)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['requester_id'],
      'FROM' => 'glpi_plugin_formcreator_formanswers',
      'WHERE' => ['id' => $id_answer]
  ]);
  return $iterator->current()['requester_id'] ?? 0;
}

function getMailsOfGroup($group_name)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['u.id AS user_id', 'u.name AS user_name', 'gu.groups_id AS group_id', 'g.name AS group_name', 'um.email AS user_email'],
      'FROM' => 'glpi_users AS u',
      'INNER JOIN' => [
        'glpi_groups_users AS gu' => [
           'ON' => [
              'u' => 'id',
              'gu' => 'users_id',
           ]
        ]
      ],
      'JOIN' => [
        'glpi_groups AS g' => [
           'ON' => [
              'gu' => 'groups_id',
              'g' => 'id',
           ]
        ]
      ],
      'LEFT JOIN' => [
        'glpi_useremails AS um' => [
           'ON' => [
              'u' => 'id',
              'um' => 'users_id',
           ]
        ]
      ],
      'WHERE' => [
        'g.name' => $group_name,
      ]
  ]);
  $emails = []; foreach ($iterator as $row) $emails[] = $row['user_email'];
  return $emails;
}

function formatDate($date)
{
  return implode('/', array_reverse(explode('-', $date)));
}

function formatDateTime($date_time)
{
  $arr = explode(' ', strip_tags($date_time));
  return "<span class='text-nowrap'>".formatDate($arr[0]).' '.($arr[1] ?? '')."</span>";
}

function getValideurWithDateValidation($id_answer)
{
  $answers = getAnswers($id_answer);
  $date_validation = $answers[getIdField('validation', 'Date')]['answer'] ?? '';
  $date_validation = explode(' ', $date_validation)[0];
  $date_validation = formatDate($date_validation);
  $valideur = $answers[getIdField('validation', 'Nom')]['answer'] ?? '';
  $ret = "$date_validation $valideur";
  $validation = getAnswerValidation($id_answer);
  if ($validation != '') {
    $color = $validation == 'Valider' ? 'green' : 'red';
    $ret = "<span class='text-nowrap' style='color:$color'>$ret</span>";
  }
  return $ret;
}

function formatAnswersList(&$data) 
{
  foreach($data['data']['rows'] as $key => $value) {
    $data['data']['rows'][$key]['PluginFormcreatorFormAnswer_5']['displayname'] = getValideurWithDateValidation($value['id']);
    $data['data']['rows'][$key]['PluginFormcreatorFormAnswer_6']['displayname'] = formatDateTime($value['PluginFormcreatorFormAnswer_6']['displayname']);
  }
}

function getMailsValideur($id_user)
{
  $user = getUser($id_user);
  $idEntity = $user['entities_id'];
  $idGroupValidation = getIdGroupByName('validation');
  $users = getUsersByGroupId($idGroupValidation);
  $mails_valideur = [];
  foreach($users AS $user) {
    if (isset($user['id_entity']) && $user['id_entity'] == $idEntity)
      $mails_valideur[] = $user['email'];
  }
  return $mails_valideur;
}

// Récupérer mail des valideurs appartenant à la même entité, autre que racine, que l'utilisateur
function getMailsValideurWithSameEntity($id_user)
{
  $user = getUser($id_user);
  $idEntity = $user['entities_id'];
  $mails_valideur = [];
  if($idEntity!==0){
    $idGroupValidation = getIdGroupByName('validation');
    $users = getUsersByGroupId($idGroupValidation);
    foreach($users AS $user) {
      if ($user['id_entity'] == $idEntity)
        $mails_valideur[] = $user['email'];
    }
  }
  
  return $mails_valideur;
}

?>