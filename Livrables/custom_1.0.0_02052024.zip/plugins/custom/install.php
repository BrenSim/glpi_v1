<?php
// Messages associés à différents retours d'installation
$msg = [
    "Installation terminée avec succès.",
    "Le module est déjà installé.",
    "Installation abandonnée. Impossible d'accéder au template footer.",
];

// Fonction d'installation
function install() {
    // Inclusion du fichier de configuration pour les informations de la base de données
    include('config.php');
    // Connexion à la base de données
    $pdo = new PDO($db_host, $db_user, $db_pass);

    // Chargement du formulaire de dysfonctionnement
    $sql = file_get_contents('install_data.sql');
    // Conversion de l'encodage du contenu en UTF-8
    // $contenuUTF8 = iconv('ISO-8859-1', 'UTF-8', $sql);
    $pdo->exec($sql);

    // Vidage de certaines tables dans la base de données
    $pdo->query("TRUNCATE TABLE glpi_plugin_formcreator_formanswers");
    $pdo->query("TRUNCATE TABLE glpi_plugin_formcreator_answers");

    // Chemin vers le répertoire où le plugin doit effectuer des opérations
    $path = '../../templates/layout/parts/';
    // Tentative de création et d'écriture dans un fichier test.txt
    $fp = fopen($path.'test.txt', 'w');
    if (empty($fp)) return 2;
    fwrite($fp, 'test');
    fclose($fp);
    // Tentative de suppression du fichier test.txt
    if (!unlink($path.'test.txt')) return 2;

    // Opérations sur le fichier footer
    $footer = 'page_footer.html.twig';
    copy('formcreator_custom.html.twig', $path.'formcreator_custom.html.twig');
    $fp = fopen($path.$footer, 'r'); 
    if (empty($fp)) return 2;

    // Vérification et modification du contenu du fichier footer
    $content = file_get_contents($path.$footer);
    if (strpos($content, "formcreator_custom") > 0) return 1;
    $pos = strpos($content, "</body>");
    $insert = "   {% include 'layout/parts/formcreator_custom.html.twig' %}\r\r";
    $content = substr($content, 0, $pos).$insert.substr($content, $pos);
    file_put_contents($path.$footer, $content);

    return 0; // Retour d'installation réussie
}
try {
    $ret = install(); // Appel de la fonction d'installation
} catch (\Exception $e) {
    die("Une erreur s'est produite.".$e->getMessage()); // Affichage d'une erreur en cas d'exception
}
?>
<!-- Contenu HTML pour afficher le résultat de l'installation -->
<h4>Installation du module import/export du plugins <i>formcreater</i></h4>
<p><?php echo $msg[$ret]; ?></p> <!-- Affichage du message correspondant au retour de l'installation -->