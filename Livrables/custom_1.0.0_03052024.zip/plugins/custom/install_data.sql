
TRUNCATE TABLE `glpi_plugin_formcreator_forms`;
INSERT INTO `glpi_plugin_formcreator_forms` (`id`, `name`, `entities_id`, `is_recursive`, `icon`, `icon_color`, `background_color`, `access_rights`, `description`, `content`, `plugin_formcreator_categories_id`, `is_active`, `language`, `helpdesk_home`, `is_deleted`, `validation_required`, `usage_count`, `is_default`, `is_captcha_enabled`, `show_rule`, `formanswer_name`, `is_visible`, `uuid`) VALUES
(1, 'Signalement de dysfonctionnement', 0, 0, 'fa fa-list-alt', '#999999', '#e7e7e7', 1, '', '', 0, 1, 'fr_FR', 1, 0, 0, 66, 1, 0, 1, 'Signalement de dysfonctionnement', 1, '46438aef-a88c4157-656dccad9c76d2.24569661');

TRUNCATE TABLE `glpi_plugin_formcreator_sections`;
INSERT INTO `glpi_plugin_formcreator_sections` (`id`, `name`, `plugin_formcreator_forms_id`, `order`, `show_rule`, `uuid`) VALUES
(1, 'Signalement de dysfonctionnement', 1, 1, 1, '46438aef-a88c4157-656dccd35bffb2.25627297'),
(2, 'Déposé par', 1, 2, 1, '46438aef-a88c4157-656dccfeb0da25.93785106'),
(3, 'Sous couvert de', 1, 3, 1, '46438aef-a88c4157-656dcd6628e0c3.81353971'),
(4, 'Personne à contacter', 1, 4, 1, '46438aef-a88c4157-656dcdaa326102.64402555'),
(5, 'Localisation du dysfonctionnement', 1, 5, 1, '46438aef-a88c4157-656dce1a41c439.89206132'),
(6, 'Partie réservée au BMO', 1, 6, 1, '46438aef-a88c4157-656dcf53843a88.79073653'),
(7, 'Section', 2, 1, 1, '46438aef-a88c4157-656ecd48b65288.98328655'),
(8, 'Partie réservée pour la validation', 1, 7, 1, '46438aef-a88c4157-6617f0c0e273f9.17481014');

TRUNCATE TABLE `glpi_plugin_formcreator_questions`;
INSERT INTO `glpi_plugin_formcreator_questions` (`id`, `name`, `plugin_formcreator_sections_id`, `fieldtype`, `required`, `show_empty`, `default_values`, `itemtype`, `values`, `description`, `row`, `col`, `width`, `show_rule`, `uuid`) VALUES
(1, 'Date du signalement', 1, 'date', 1, 0, '', '', NULL, '', 0, 0, 4, 1, '46438aef-a88c4157-656dccf01345e6.70749387'),
(2, 'Nom', 2, 'text', 1, 0, '', '', NULL, '', 0, 0, 4, 1, '46438aef-a88c4157-656dcd1cabf979.72974296'),
(3, 'Prénom', 2, 'text', 1, 0, '', '', NULL, '', 1, 0, 4, 1, '46438aef-a88c4157-656dcd4915bbc0.78159996'),
(4, 'Fonction', 2, 'text', 1, 0, '', '', NULL, '', 2, 0, 4, 1, '46438aef-a88c4157-656dcd593128b1.57905224'),
(5, 'Nom', 3, 'text', 1, 0, '', '', NULL, '', 0, 0, 4, 1, '46438aef-a88c4157-656dcd75bbc0f1.14501669'),
(6, 'Prénom', 3, 'text', 1, 0, '', '', NULL, '', 1, 0, 4, 1, '46438aef-a88c4157-656dcd881c93d9.35244050'),
(7, 'Fonction', 3, 'text', 1, 0, '', '', NULL, '', 2, 0, 4, 1, '46438aef-a88c4157-656dcd9dd0c632.15774484'),
(8, 'Nom', 4, 'text', 1, 0, '', '', NULL, '', 0, 0, 4, 1, '46438aef-a88c4157-656dcdbde341a3.70162525'),
(9, 'Prénom', 4, 'text', 1, 0, '', '', NULL, '', 1, 0, 4, 1, '46438aef-a88c4157-656dcdcf618a22.17829264'),
(10, 'Fonction', 4, 'text', 1, 0, '', '', NULL, '', 2, 0, 4, 1, '46438aef-a88c4157-656dcde80945d7.71833832'),
(11, 'Courriel', 4, 'email', 1, 0, '', '', '', '', 3, 0, 4, 1, '46438aef-a88c4157-656dcdf96c10f5.63883353'),
(12, 'Téléphone(s)', 4, 'text', 1, 0, '', '', NULL, '', 4, 0, 4, 1, '46438aef-a88c4157-656dce0b4c4501.46460627'),
(13, 'Bâtiment', 5, 'checkboxes', 1, 0, '', '', '[\"E\",\"F\",\"G\",\"H\",\"I\",\"Parking\",\"Cour\"]', '', 0, 0, 4, 1, '46438aef-a88c4157-656dce4b1289e0.70684385'),
(14, 'Niveau', 5, 'checkboxes', 1, 0, '', '', '[\"Sous-sol -2\",\"Sous-sol -1\",\"Cour basse\",\"Cour haute\",\"RdC\",\"1er\",\"2ème\",\"Terrasse\",\"Toiture\"]', '', 1, 0, 4, 1, '46438aef-a88c4157-656dce8acadfd1.53760472'),
(15, 'Description précise du dysfonctionnement', 5, 'textarea', 1, 0, '', '', NULL, '', 2, 0, 4, 1, '46438aef-a88c4157-656dcea7684531.41990226'),
(16, 'Niveau d impact sur l activité', 5, 'radios', 1, 0, NULL, '', '[\"Faible\",\"Moyen\",\"Elevé\",\"Très Elevé\",\"Rhédibitoire\"]', '', 3, 0, 4, 1, '46438aef-a88c4157-656dcf1bf315a5.74409076'),
(17, 'Qualification du dysfonctionnement', 5, 'radios', 1, 0, NULL, '', '[\"Informative\",\"Importante\",\"Critique\"]', '', 4, 0, 4, 1, '46438aef-a88c4157-656dcf460df579.35354507'),
(18, 'Signalement reçu le', 6, 'date', 1, 0, '', '', NULL, '', 1, 0, 4, 1, '46438aef-a88c4157-656dcf679f8799.60527757'),
(19, 'Caractérisation de la demande', 6, 'radios', 1, 0, NULL, '', '[\"GPA\",\"Maintenance Exploitation\",\"PPI\"]', '', 2, 0, 4, 1, '46438aef-a88c4157-656dcf895bb494.15389972'),
(20, 'Prise en charge apportée', 6, 'radios', 1, 0, NULL, '', '[\"Ouverture de fiche GPA n°\",\"Création d une Demande d Intervention TECHBASE\",\"Transmission d une Demande d Intervention au SQUR\",\"Transmission pour inscription PPI\\/TMGR DBL ou DEA\"]', '', 3, 0, 4, 1, '46438aef-a88c4157-656dcfbc6f3269.28711174'),
(21, 'Référent de la prise en charge', 6, 'radios', 1, 0, NULL, '', '[\"BMO\\/SIMO\\/DBL\",\"BEX\\/SBD\\/DBL\",\"BPTM\\/SBD\\/DBL\",\"BMT\\/SQUR\\/DEA\"]', '', 4, 0, 4, 1, '46438aef-a88c4157-656dcff155cdc2.70019254'),
(22, 'Observations', 6, 'textarea', 1, 0, '', '', NULL, '', 5, 0, 4, 1, '46438aef-a88c4157-656dd0337bec13.47571397'),
(23, 'Signalement clôturé le', 6, 'date', 1, 0, '', '', NULL, '', 6, 0, 4, 1, '46438aef-a88c4157-656dd0494223c1.12028883'),
(24, 'Date du constat de dysfonctionnement', 5, 'date', 1, 0, '', '', NULL, '', 5, 0, 4, 1, '46438aef-a88c4157-656ebd25404a75.08645097'),
(30, 'N° demande', 6, 'text', 1, 0, '', '', NULL, '', 0, 0, 4, 1, '22466f70-a88c4157-65e6dcd0627723.04351924'),
(35, 'Visa Direction ou Service', 8, 'checkboxes', 1, 0, '', '', '[\"Viser\"]', '', 1, 0, 4, 1, '46438aef-a88c4157-6617f0f014bb36.98096352'),
(37, 'Visa du demandeur', 5, 'checkboxes', 1, 0, '', '', '[\"Viser\"]', '', 6, 0, 4, 1, '46438aef-a88c4157-6617f1ebc65497.24494294'),
(38, 'Nom du valideur', 8, 'text', 0, 0, '', '', NULL, '', 0, 0, 4, 1, '46438aef-a88c4157-661cfab7efaba4.04621935'),
(39, 'Date de validation', 8, 'date', 0, 0, '', '', NULL, '', 0, 0, 4, 1, 'e150908b-328c3424-6620eec7a8c4f0.02934657');


