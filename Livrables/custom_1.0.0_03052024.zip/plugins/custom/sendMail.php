<?php

require_once "vendor/autoload.php";
require __DIR__ . '/vendor/autoload.php';
include 'config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

use GuzzleHttp\Client;

function SendMail($htmlContent, $recipient, $sujet)
{

    $mail = new PHPMailer(true);

    try {
        // Paramètres du serveur SMTP
        $mail->isSMTP();
        $mail->Host = MailConfig::$host;
        $mail->SMTPAuth = MailConfig::$SMTPAuth;
        $mail->Username = MailConfig::$username;
        $mail->Password = MailConfig::$password;
        $mail->SMTPAutoTLS = MailConfig::$SMTPAutoTLS;
        $mail->Port = MailConfig::$port;
        $mail->CharSet = MailConfig::$charset;

        // Destinataire, sujet et corps de l'e-mail
        $mail->setFrom(MailConfig::$from['address'], MailConfig::$from['name']);
        if (!is_array($recipient)) $recipient = [$recipient];
        $send = false;
        foreach($recipient as $to) if($to != null || $to != '' ) { $mail->addAddress($to); $send = true; }
        if (!$send) return;
        $mail->Subject = $sujet;
        $mail->addReplyTo(MailConfig::$replyto['address'], MailConfig::$replyto['name']);
        $mail->msgHTML($htmlContent);
        // $mail->addStringAttachment($fileContent, $fileName);
        
        // Envoi de l'e-mail
        $mail->send();
        // echo 'L\'e-mail a été envoyé avec succès.';
    } catch (Exception $e) {
        echo "Une erreur s'est produite lors de l'envoi de l'e-mail : {$mail->ErrorInfo}";
    }
    
}
