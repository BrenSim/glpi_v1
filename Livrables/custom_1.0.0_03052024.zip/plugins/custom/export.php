<?php
// $s = '["Sous-sol -2","Sous-sol -1","Cour basse","Cour haute","RdC","1er","2me","Terrasse","Toiture"]';
// print_r(json_decode($s));
// die;
include('config.php');
$file = 'export.csv';
$fp = fopen($file, 'wt');
$pdo = new PDO($db_host, $db_user, $db_pass);
$res = $pdo->query("SELECT s.id s_id, s.name s_name, q.id q_id, q.name q_name, q.values q_values, fieldtype
                        FROM glpi_plugin_formcreator_questions q
                        JOIN glpi_plugin_formcreator_sections s ON s.id = q.plugin_formcreator_sections_id
                        WHERE s.plugin_formcreator_forms_id = 1
                        ORDER BY s.order, q.row;");
$questions = [];
foreach($res as $row) $questions[$row['q_id']] = $row;
$res = $pdo->query("SELECT plugin_formcreator_formanswers_id f_id, plugin_formcreator_questions_id q_id, answer FROM glpi_plugin_formcreator_answers ORDER BY plugin_formcreator_formanswers_id, plugin_formcreator_questions_id;");
$titles = "date_signalement;depose_par_nom;depose_par_prenom;depose_par_fonction;sous_couvert_de_nom;sous_couvert_de_prenom;sous_couvert_de_fonction;personne_a_contacter_nom;personne_a_contacter_prenom;personne_a_contacter_fonction;personne_a_contacter_courriel;personne_a_contacter_telephones;batiment_e;batiment_f;batiment_g;batiment_h;batiment_i;batiment_parking;batiment_cour;niveau_sous_sol_2;niveau_sous_sol_1;niveau_cour_basse;niveau_cour_haute;niveau_rdc;niveau_1;niveau_2;niveau_terrasse;niveau_toiture;description;impact_faible;impact_moyen;impact_eleve;impact_tres_eleve;impact_redhibitoire;qualification_informative;qualification_importante;qualification_critique;date_constat;date_reception;caracterisation_gpa;caracterisation_me;caracterisation_ppi;prise_en_charge_ouverture_fiche_gpa;prise_en_charge_creation_demande_intervention;prise_en_charge_transmission_demande_intervention;prise_en_charge_transmission_inscription;referent_pec_bmo_simo_dbl;referent_pec_bex_sbd_dbl;referent_pec_bptm_sbd_dbl;referent_pec_bmt_squr_dea;observations;date_cloture";
$fields = explode(";", $titles);
fputs($fp, $titles."\n");
$old_id = '';
foreach($res as $item) {
    $id = $item['f_id'];
    if ($old_id != '' && $id != $old_id) fputs($fp, "\n");
    $old_id = $id;
    $answer = $item['answer'];
    $answer = str_replace("\\", "", $answer);
    $question = $questions[$item['q_id']];
    echo "ID=".$item['q_id']."|".$question['q_values']."|".$question['fieldtype'].PHP_EOL;
    if (in_array($question['fieldtype'], ['checkboxes', 'ratios'])) {
        print_r(json_decode($question['q_values']));
        
        // echo $question['q_values'].PHP_EOL;
        // print_r(json_decode($question['q_values'])).PHP_EOL;
        // echo $answer.PHP_EOL;
        
        foreach(json_decode($question['q_values']) as $val) {
            if (in_array($val, json_decode($answer)))
                fputs($fp, '1;');
            else
                fputs($fp, ';');
        }


    } else {
        fputs($fp, $answer.";");
    }
    // if ($item['q_id'] == count($fields)) fputs($fp, "\n");
}
die;
fclose($fp);
header("Content-Disposition: attachment; filename=\"" . basename($file) . "\"");
header("Content-Type: application/octet-stream");
header("Content-Length: " . filesize($file));
header("Connection: close");
readfile($file);